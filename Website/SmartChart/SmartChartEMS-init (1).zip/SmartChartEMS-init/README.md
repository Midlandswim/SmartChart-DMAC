
Live at: https://smartchart.streamlit.app/ 

Award winning* software that is the most intelligent and efficient virtual patient charting application for emergency medical technicians on the market. Utilizes an algorithm that suggests treatment based on patient information, a machine learning model that provides diagnostics and appropriate protocols, and more. Supports audio transcription and translation for patient charting and communication.


*Won 1st place at the HOSA New Jersey State Conference for Medical Innovation
